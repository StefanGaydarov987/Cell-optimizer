﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cell_optimizer
{
    public class EnergyCalculator
    {
        public double CalculateEnergy(Point3D a, Point3D b, Point3D c, Point3D d)
        {
            double energy = 0;

            double distAB = Distance(a, b);
            

            double distAC = Distance(a, c);

            double distAD = Distance(a, d);


            double distBC = Distance(b, c);


            double distBD = Distance(b, d);


            double distCD = Distance(c, d);


            // Calculate v1 based on Z coordinates of points
            double zA = a.Z;
            double zB = b.Z;
            double zC = c.Z;
            double zD = d.Z;
            energy += V2(distAB)+ V2(distAC)+ V2(distAD)+ V2(distBC)+ V2(distBD)+ V2(distCD) + V1(zA) + V1(zB) + V1(zC) + V1(zD);

            return energy;
        }

        private double Distance(Point3D p1, Point3D p2)
        {
            return Math.Sqrt(Math.Pow(p1.X - p2.X, 2) + Math.Pow(p1.Y - p2.Y, 2) + Math.Pow(p1.Z - p2.Z, 2));
        }

        private double V1(double x)
        {
            if (x > 3.0 / 2.0)
                return x * x; // v1(x) = x^2
            else
                return 0;
        }

        private double V2(double x)
        {
            if (x <= 1)
                return 1 - x * x; // For x in [0, 1]
            else
                return x * x - 1; // For x > 1
        }
    }

}
