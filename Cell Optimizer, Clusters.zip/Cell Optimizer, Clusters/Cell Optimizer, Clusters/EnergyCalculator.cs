﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cell_Optimizer__Clusters
{
    public class EnergyCalculator
    {
        public double CalculateEnergy(Point3D a, Point3D b, Point3D c, Point3D d)
        {
            double energy = 0;

            // Calculate v1(h) for points A, B, C, and D
            energy += V1(a.Z) + V1(b.Z) + V1(c.Z) + V1(d.Z);

            // Calculate v2(l) for all pairs of points
            energy += V2(Distance(a, b)) + V2(Distance(a, c)) + V2(Distance(a, d)) +
                      V2(Distance(b, c)) + V2(Distance(b, d)) + V2(Distance(c, d));

            return Math.Max(0, energy); // Ensure the energy is nonnegative
        }

        private double Distance(Point3D p1, Point3D p2)
        {
            return Math.Sqrt(Math.Pow(p1.X - p2.X, 2) + Math.Pow(p1.Y - p2.Y, 2) + Math.Pow(p1.Z - p2.Z, 2));
        }

        private double V1(double x)
        {
            return 2 * Math.Pow(x, 2) - 3 * x / 2.0;
        }

        private double V2(double x)
        {
            if (x < 0 || x >= 1)
            {
                return x * x - 1;
            }
            return 1 - x * x;
        }
    }

}
