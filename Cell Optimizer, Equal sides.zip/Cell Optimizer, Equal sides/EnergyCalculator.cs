﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cell_Optimizer__Equal_sides
{
    public class EnergyCalculator
    {

        public double CalculateEnergy(Point3D a, Point3D b, Point3D c, Point3D d)
        {
            double energy = 0;
            double zA = a.Z;
            double zB = b.Z;
            double zC = c.Z;
            double zD = d.Z;

            double distAB = Distance(a, b);

            double distBC = Distance(b, c);


            double distCD = Distance(c, d);


            double distAD = Distance(a, d);


            double distAC = Distance(a, c);


            double distBD = Distance(b, d);

            energy += V2(distAB) + V2(distAC) + V2(distAD) + V2(distBC) + V2(distBD) + V2(distCD) + V1(zA) + V1(zB) + V1(zC) + V1(zD);

            return energy;
        }

        private double Distance(Point3D p1, Point3D p2)
        {
            return Math.Sqrt(Math.Pow(p1.X - p2.X, 2) + Math.Pow(p1.Y - p2.Y, 2) + Math.Pow(p1.Z - p2.Z, 2));
        }

        private double V1(double x)
        {
            return x * x; // v1(x) = x^2
        }

        private double V2(double x)
        {
            if (x != 1)
                return x*x/2 - x + 1; // For x not equal to 1
            else
                return 0; // For x = 1
        }
    }

}
