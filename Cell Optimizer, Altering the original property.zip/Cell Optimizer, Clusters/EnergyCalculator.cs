﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cell_Optimizer__Clusters
{
    
    public class EnergyCalculator
    {
        private const double Pi = Math.PI;

        public double CalculateEnergy(Point3D a, Point3D b, Point3D c, Point3D d)
        {
            double energy = 0;

            double angleA = Angle(a, b, c);
            double angleB = Angle(b, c, d);
            double angleC = Angle(c, d, a);
            double angleD = Angle(d, a, b);

            // Calculate energy using angles and V3 function
            energy += V3(angleA);


            double distAB = Distance(a, b);
            energy += V2(distAB);

            

            double distDA = Distance(d, a);
            energy += V2(distDA);


            double distBD = Distance(b, d);
            energy += V2(distBD);

            return energy;
        }

        private double Distance(Point3D p1, Point3D p2)
        {
            return Math.Sqrt(Math.Pow(p1.X - p2.X, 2) + Math.Pow(p1.Y - p2.Y, 2) + Math.Pow(p1.Z - p2.Z, 2));
        }
        private double Angle(Point3D a, Point3D b, Point3D c)
        {
            double distAB = Distance(a, b);
            double distAC = Distance(a, c);
            double distBC = Distance(b, c);
            return Math.Acos((distAB * distAB + distAC * distAC - distBC * distBC) / (2 * distAB * distAC));
        }

        private double V2(double x)
        {
            if (x >= 0 && x <= 1)
                return 2 * x * x - 15 * x + 12; // For x in [0, 1]
            else
                return 3.0 / 4.0 - 1.0 / (2.0 * Math.Sqrt(2.0)) - (7.0 / 4.0 + 3.0 / (2.0 * Math.Sqrt(2.0))) * x + Math.Sqrt(2.0) * x * x;
            // return 3.0 / 4.0 - 1.0 / (2.0 * Math.Sqrt(2.0)) - (7.0 / 4.0 + 3.0 / (2.0 * Math.Sqrt(2.0))) * x + Math.Sqrt(2.0) * x * x * 2;
            // return Math.Sqrt(2) * x * x - ((7.0 / 4) + (3 * Math.Sqrt(2) / 4)) * x + 3 / 4 - 1/(2*Math.Sqrt(2)); // For x > 1}
        }
        private double V3(double x)
        {
            if (x >= 0 && x <= Pi / 2)
                return (4 / (2 * Pi - 1)) * x * x - 6 * x + 1.0 / 2 + 3 * Pi - Pi * Pi / (2 * Pi - 1);
            else
                return (2 * (Pi - 1) * x * x) / (3 * Pi * Pi) - x + (2 + Pi) / 3;
        }
    }
}
